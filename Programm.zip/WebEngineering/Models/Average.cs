﻿namespace WebEngineering.Models
{
    public class Average
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public decimal DurchschnittlicheBestellmenge { get; set; }
        public decimal DurchschnittlicheLiefermenge { get; set; }
    }
}
