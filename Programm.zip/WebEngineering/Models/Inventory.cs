﻿namespace WebEngineering.Models
{
    public class Inventory
    {
        public DateTime Datum { get; set; }
        public int Lagerbestand { get; set; }
    }
}
