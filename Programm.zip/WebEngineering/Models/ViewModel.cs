﻿namespace WebEngineering.Models
{
    public class ViewModel
    {
        public int Id { get; set; }
        public Produkt Produkt { get; set; }
        public Bestellung Bestellung { get; set; }
        public Lieferung Lieferung { get; set; }
    }
}
